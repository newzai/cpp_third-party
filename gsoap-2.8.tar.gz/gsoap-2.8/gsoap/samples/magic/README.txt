Example magic square client and servers.

The client 'magic' application invokes the magic square service on our web site.

The 'magicserver' demonstrates a CGI-based server and stand-alone multi-threaded
server (if pthreads is available).

