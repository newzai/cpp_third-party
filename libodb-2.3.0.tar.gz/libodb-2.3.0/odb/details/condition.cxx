// file      : odb/details/condition.cxx
// copyright : Copyright (c) 2009-2013 Code Synthesis Tools CC
// license   : GNU GPL v2; see accompanying LICENSE file

#include <odb/details/condition.hxx>

namespace odb
{
  namespace details
  {
    // This otherwise unnecessary file is here to allow instantiation
    // of inline functions for exporting.
  }
}
