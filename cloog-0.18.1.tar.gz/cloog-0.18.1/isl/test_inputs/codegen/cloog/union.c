if (M >= 11) {
  for (int c0 = -100; c0 <= 0; c0 += 1)
    S1(-c0);
} else
  for (int c0 = 0; c0 <= 100; c0 += 1)
    S1(c0);
