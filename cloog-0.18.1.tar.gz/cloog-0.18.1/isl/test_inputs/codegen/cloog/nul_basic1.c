for (int c0 = 0; c0 <= M; c0 += 2)
  S1(c0, c0 / 2);
