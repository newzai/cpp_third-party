for (int c0 = 2; c0 <= 9; c0 += 1)
  s0(c0);
