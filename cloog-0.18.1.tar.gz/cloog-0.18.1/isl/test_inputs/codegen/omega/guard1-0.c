if (n + 3 * floord(-n + m - 2, 3) + 2 == m)
  s0(n, m);
