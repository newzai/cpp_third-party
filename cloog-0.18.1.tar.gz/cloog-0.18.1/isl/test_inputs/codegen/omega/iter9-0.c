for (int c0 = 1; c0 <= 15; c0 += 1) {
  if (8 * floord(7 * exprVar1 + 7, 8) + 8 >= 7 * exprVar1 + c0) {
    s4(c0);
    s0(c0);
    s3(c0);
    s2(c0);
    s1(c0);
  }
  if (8 * floord(7 * exprVar1 + 7, 8) + 8 >= 7 * exprVar1 + c0 || (exprVar1 + 8 * floord(-exprVar1 + c0 - 1, 8) + 1 == c0 && c0 >= exprVar1 + 1))
    s5(c0);
}
