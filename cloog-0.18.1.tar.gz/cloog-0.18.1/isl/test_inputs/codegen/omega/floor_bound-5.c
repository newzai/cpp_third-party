for (int c0 = 4 * floord(m, 32); c0 <= n; c0 += 1)
  s0(c0);
